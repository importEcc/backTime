<template>
    <div class="index">
        <div class='card_table'>
            <div class="card_text">
                <p class="card_table_text">表格</p>
                <p class="card_table_text wenzi">Label</p>
            </div>
            
        </div>
    </div>
</template>
<script>
export default {
    name:'index'
}
</script>
<style lang="scss">
@import "./index.scss"
</style>
