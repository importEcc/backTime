<template>
    <div class="errors">
        404
    </div>
</template>
<script>
export default {
    name:"errors"
}
</script>
<style lang="scss">
@import "./404.scss"
</style>

